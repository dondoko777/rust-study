#[no_mangle]
pub extern fn hello() {
   println!("Hello rust world.");
}
