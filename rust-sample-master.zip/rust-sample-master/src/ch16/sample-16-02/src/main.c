void hello(void);
int main(){
    hello();
}