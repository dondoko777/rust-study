#include<stdio.h>

void hello(){
    printf("hello C world.\n");
}

int c_add( int x, int y ) {
    return x + y ;
}